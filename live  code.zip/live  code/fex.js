const fs = require('fs');

function saveToFex(tokenData) {
    let fexData = [];
    if (fs.existsSync('./fex.json')) {
        try {
            fexData = JSON.parse(fs.readFileSync('./fex.json', 'utf8'));
        } catch (e) {
            fexData = [];
        }
    }
    
    fexData.push({
        token: tokenData.token,
        reason: tokenData.reason,
        failedAt: new Date().toISOString()
    });

    fs.writeFileSync('./fex.json', JSON.stringify(fexData, null, 2));
}

module.exports = { saveToFex };